﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DragomSave
{
    class Game
    {
        public int ED1 { get; set; } = 0;
        public int LD1 { get; set; } = 0;
        public int ED2 { get; set; } = 0;
        public int LD2 { get; set; } = 0;
        public int ED3 { get; set; } = 0;
        public int LD3 { get; set; } = 0;
        public int ED4 { get; set; } = 0;
        public int LD4 { get; set; } = 0;  
    }
}
